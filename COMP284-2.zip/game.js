var grid =
    [['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],
     ['','','','','','','','','',''],]


var table = document.getElementById("table")
var gameSetNotify=document.getElementById("gameSetNotify")

//other initail variables
var game1stStage = "setup"
var userspaceshipnum=0
var roboticspaceshipnum=0
var asteroidnum=0
var minenum=0
var roundnum=1
var userrow
var usercolumn

var validinput="amru"


function initTable(table) {
    for (var y = 0; y < grid.length; y++) {
        var tr = document.createElement("tr")
        table.appendChild(tr)
        for (var x = 0; x < grid[y].length; x++) {
            var td = document.createElement("td")
            var txt = document.createTextNode(" ")
            td.appendChild(txt)
            td.addEventListener("click", setGrid.bind(null, x, y), false)
            tr.appendChild(td)
        }
    }
}

function init() {
    document.getElementById("gameStageNotify").innerHTML = "setting ur grid now"
    initTable()
}
initTable(table)

function setGrid(x,y,event){
if(game1stStage == "setup"){
if (grid[x][y] == 'm'||grid[x][y] == 'u'||grid[x][y] == 'r'||grid[x][y] == 'a') {
alert("this cell can not be modified anymore!")
}else{
var message1 = prompt("Please enter a/m/r/u in this cell:")
if(!validinput.includes(message1)||message1==''||message1.length>1||message1 == null){
alert("Please enter a/m/r/u in this cell:")
}else{
if(message1=='m'){
grid[x][y] = message1
event.target.innerHTML = message1
minenum++
}
if(message1=='r'){
grid[x][y] = message1
event.target.innerHTML = message1
roboticspaceshipnum++
}
if(message1=='a'){
grid[x][y] = message1
event.target.innerHTML = message1
asteroidnum++
}
if(message1=='u'){
if(userspaceshipnum==0){
grid[x][y] = message1 
event.target.innerHTML = message1
userspaceshipnum++
userrow=x
usercolumn=y
}else{
alert("no more user space ship allowed!")
}
}
}
}
}
}

function gameStart(){
if(userspaceshipnum!=1){
    alert("You must set one user to the grid!")
}else{
game1stStage = "play"
var gameInforInProcess= ""
gameInforInProcess +="<b>Round: "+roundnum +"</b><br>"
gameInforInProcess +="<b>Mines: "+ minenum +"</b><br>"
gameInforInProcess +="<b>Robotics spaceship: "+ roboticspaceshipnum+ "</b><br>"
document.getElementById("gameInforInProcess").innerHTML = gameInforInProcess
playStage()
}
}


function playStage() {
if (userspaceshipnum == 0 || roboticspaceshipnum== 0 || minenum == 0) {
var result = "This is the end of the game<br>"
if (userspaceshipnum==0) {
result += "the computer wins!"
} else if (roboticspaceshipnum == 0) {
result += "User wins"
}else{result += "A tie!"}
document.getElementById("result").innerHTML = result
} else {
document.getElementById("gameStageNotify").innerHTML = "its user's turn"
buttonSetting()        
}
}


function userTurn() {
if (checkMove(userrow,usercolumn,"u")) {
var input 
input = document.getElementById("textfield").value
if (input == "w" || input == "a" || input == "s" || input == "d") {
handleInput(input)
} else {
alert("Invalid input, please input again!")
}
} else {
alert("User is not able to move!")
}
checkEvent()
var gameInforInProcess= ""
gameInforInProcess +="<b>Round: "+roundnum +"</b><br>"
gameInforInProcess +="<b>Mines: "+ minenum +"</b><br>"
gameInforInProcess +="<b>Robotics spaceship: "+ roboticspaceshipnum+ "</b><br>"
document.getElementById("gameInforInProcess").innerHTML = gameInforInProcess
}

//Check the user old position.
function checkUserOldPosition() {
    if (grid[userrow][usercolumn] == "u") {
        grid[userrow][usercolumn] = ""
    } 
}

//Check the user new position.
function checkUserNewPosition() {
    if(grid[userrow][usercolumn] == " ") {
        grid[userrow][usercolumn] = "u"
    }
}

function checkMove(x,y,type) {
    for (var i=-1; i<2; i++) {
        for (var j=-1; j<2; j++) {

                if (!(i == 0 && j== 0) && inBoard(x+i,y+j) && ( (i==-1 && j==0) || (i==0 && j==-1) || (i==0 && j==1) || (i==1 && j==0) ) && gird[x+i][y+j] != "a") {
                    return true
                }
                
        }
    }
    return false
}

function inBoard(x,y) {
    return x >= 0 && x <= 9 && y >= 0 && y <= 9 
}

function checkSomeOneCanMove() {

    if (userspaceshipnum != 0 && checkMove(userrow, usercolumn, "u")) {
        return true
    }

    return false
}

function handleInput(input) {
    if (input == "w") {
        if (userrow == 0) {
            showInformation("Outside the grid, move fails")
        }
        else if (gird[userrow-1][usercolumn] == "a") {
            showInformation("Cell occupied by an asteroid, move fails")
        }
        else {
            checkUserOldPosition()
            userrow--
            checkUserNewPosition()

        }
    }

    if (input == "a") {
        if (usercolumn == 0) {
            showInformation("Outside the grid, move fails")
        }
        else if (grid[userrow][usercolumn-1] == "a") {
            showInformation("Cell occupied by an asteroid, move fails")
        }
        else {
            checkUserOldPosition()
            usercolumn--
            checkUserNewPosition()
        }
    }

    if (input == "s") {
        if (userrow == 9) {
            showInformation("Outside the grid, move fails")
        }
        else if (grid[userrow+1][usercolumn] == "a") {
            showInformation("Cell occupied by an asteroid, move fails")
        }
        else {
            checkUserOldPosition()
            userrow++
            checkUserNewPosition()
        }
    }

    if (input == "d") {
        if (usercolumn == 9) {
            showInformation("Outside the grid, move fails")
        }
        else if (grid[userrow][usercolumn+1] == "a") {
            showInformation("Cell occupied by an asteroid, move fails")
        }
        else {
            checkUserOldPosition()
            usercolumn++
            checkUserNewPosition()
        }
    }
}

